# Missing
sogis_geodb DB service
sogis_oereb DB service


/geodata/geodata/ch.bl.agi.lidar_2018.ndsm_buildings/ch.bl.agi.lidar_2018.ndsm_buildings.tif
/geodata/geodata/ch.bl.agi.lidar_2018.ndsm_vegetation/ch.bl.agi.lidar_2018.ndsm_vegetation.tif
/geodata/geodata/ch.bl.agi.lidar_2018.ndsm_vegetation/ch.bl.agi.lidar_2018.ndsm_vegetation.tif
/geodata/geodata/ch.so.ada.schanzenplaene/Schanzenplan_GeoTiff_compressed_Deflate.tif
/geodata/geodata/ch.so.agi.orthofoto_2013.cir/orthofoto_2013_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2013.cir/orthofoto_2013_cir_12_5cm.vrt
/geodata/geodata/ch.bl.agi.orthofoto_2015.rgb/orthofoto_2015_rgb_5m.tif
/geodata/geodata/ch.bl.agi.orthofoto_2015.rgb/orthofoto_2015_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.lidar_2019.dtm_hillshade/ch.so.agi.lidar_2019.dtm_hillshade.tif
/geodata/geodata/ch.so.agi.orthofoto_2016.cir/orthofoto_2016_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2016.cir/orthofoto_2016_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.ndom/lidar_2014_ndom_5m.tif
/geodata/geodata/ch.so.agi.lidar_2019.dtm_slope/ch.so.agi.lidar_2019.dtm_slope.tif
/geodata/geodata/ch.swisstopo.satellitenbilder_2015_04.rgb/satellitenbilder_2015_04_rgb.vrt
/geodata/geodata/ch.so.agi.orthofoto_2016.rgb/orthofoto_2016_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2016.rgb/orthofoto_2016_rgb_12_5cm.vrt
/geodata/geodata/ch.so.afu.nadelstich_tiefenlayer/nadelstich_tiefenlayer.tif
/geodata/geodata/ch.bl.agi.lidar_2018.dsm_hillshade/ch.bl.agi.lidar_2018.dom_hillshade.tif
/geodata/geodata/ch.so.agi.lidar_2019.dsm_hillshade/ch.so.agi.lidar_2019.dom_hillshade.tif
/geodata/geodata/ch.swisstopo.dufourkarte/dufourkarte.vrt
/geodata/geodata/ch.so.agi.orthofoto_2017.cir/orthofoto_2017_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2017.cir/orthofoto_2017_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2017.rgb/orthofoto_2017_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2017.rgb/orthofoto_2017_rgb_12_5cm.vrt
/geodata/geodata/ch.swisstopo.siegfriedkarte/siegfriedkarte.vrt
/geodata/geodata/ch.so.ada.schanzenplaene/Schanzenplan_GeoTiff_compressed_Deflate.tif
/geodata/geodata/ch.bl.agi.lidar_2018.dtm_hillshade/ch.bl.agi.lidar_2018.dtm_hillshade.tif
/geodata/geodata/ch.so.agi.lidar_2019.ndsm_buildings/ch.so.agi.lidar_2019.ndsm_buildings.tif
/geodata/geodata/ch.so.agi.lidar_2019.ndsm_vegetation/ch.so.agi.lidar_2019.ndsm_vegetation.tif
/geodata/geodata/ch.so.agi.lidar_2019.ndsm_vegetation/ch.so.agi.lidar_2019.ndsm_vegetation.tif
/geodata/geodata/ch.bl.agi.lidar_2018.dtm_slope/ch.bl.agi.lidar_2018.dtm_slope.tif
/geodata/geodata/ch.so.walkerkarte/walker_1832.tif
/geodata/geodata/ch.so.agi.uebersichtsplan/uebersichtsplan.vrt
/geodata/geodata/ch.so.agi.orthofoto_2017.cir/orthofoto_2017_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2017.cir/orthofoto_2017_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2016.cir/orthofoto_2016_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2016.cir/orthofoto_2016_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2013.cir/orthofoto_2013_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2013.cir/orthofoto_2013_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2014.rgb/orthofoto_2014_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2014.rgb/orthofoto_2014_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2015.cir/orthofoto_2015_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2015.cir/orthofoto_2015_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2014.cir/orthofoto_2014_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2014.cir/orthofoto_2014_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2013.rgb/orthofoto_2013_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2013.rgb/orthofoto_2013_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2012.rgb/orthofoto_2012_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2012.rgb/orthofoto_2012_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2012.cir/orthofoto_2012_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2012.cir/orthofoto_2012_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2011.rgb/orthofoto_2011_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2011.rgb/orthofoto_2011_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2011.cir/orthofoto_2011_cir_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2011.cir/orthofoto_2011_cir_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2007.rgb/orthofoto_2007_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2007.rgb/orthofoto_2007_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2006.rgb/orthofoto_2006_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2006.rgb/orthofoto_2006_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2002.rgb/orthofoto_2002_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2002.rgb/orthofoto_2002_rgb_50cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_1993.grau/orthofoto_1993_grau_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_1993.grau/orthofoto_1993_grau_70cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.dom/lidar_2014_dom_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.dom/lidar_2014_dom_50cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.dom_relief/lidar_2014_dom_relief_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.dom_relief/lidar_2014_dom_relief_50cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.ndom/lidar_2014_ndom_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.ndom/lidar_2014_ndom_50cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.dtm/lidar_2014_dtm_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.dtm/lidar_2014_dtm_50cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.hangneigung/lidar_2014_hangneigung_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.hangneigung/lidar_2014_hangneigung_50cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.domdiff2001/lidar_2014_domdiff2001_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.domdiff2001/lidar_2014_domdiff2001_50cm.vrt
/geodata/geodata/ch.so.agi.orthofoto_2015.rgb/orthofoto_2015_rgb_5m.tif
/geodata/geodata/ch.so.agi.orthofoto_2015.rgb/orthofoto_2015_rgb_12_5cm.vrt
/geodata/geodata/ch.so.agi.lidar_2014.dtm_relief/lidar_2014_dtm_relief_5m.tif
/geodata/geodata/ch.so.agi.lidar_2014.dtm_relief/lidar_2014_dtm_relief_50cm.vrt
/geodata/geodata/ch.swisstopo.dtm-av_2001.schattenbilder/dtm-av_2001_schattenbilder_5m.tif
/geodata/geodata/ch.swisstopo.dom_2001.schattenbilder/dom_2001_schattenbilder.vrt
/geodata/geodata/ch.swisstopo.dtm-av_2001.dtm/dtm-av_2001_dtm.vrt
/geodata/geodata/ch.swisstopo.dtm-av_2001.gradientenbilder/dtm-av_2001_gradientenbilder_5m.tif
/geodata/geodata/ch.swisstopo.dtm-av_2001.gradientenbilder/dtm-av_2001_gradientenbilder.vrt
/geodata/geodata/ch.swisstopo.dtm-av_2001.schattenbilder/dtm-av_2001_schattenbilder.vrt
/geodata/geodata/ch.so.alw.drainagenplaene.sw_zugeschnitten/drainagen.vrt

















